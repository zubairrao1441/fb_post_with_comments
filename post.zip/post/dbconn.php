<?php 
	mysql_select_db('practice', mysql_connect("localhost", "root", "")) or die ('cannot connect to database' . mysql_error());
?>