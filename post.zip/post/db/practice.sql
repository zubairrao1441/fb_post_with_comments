-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 04, 2018 at 09:52 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `practice`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `comment_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` varchar(500) NOT NULL,
  `date_posted` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`comment_id`, `post_id`, `user_id`, `content`, `date_posted`) VALUES
(0, 2, 1, 'adsadads\r\n', '1437384369'),
(0, 4, 2, 'cristy po to', '1437384585'),
(0, 4, 2, 'lkjlklkqew', '1437385594'),
(0, 4, 2, 'qewlkqewlk', '1437385807'),
(0, 4, 2, 'hahahaha', '1437385812'),
(0, 3, 2, 'wee', '1437386186'),
(0, 3, 2, ';qlt;lqlwer', '1437386275'),
(0, 3, 2, 'qewqew;lqewl;qwktqew', '1437386294'),
(0, 6, 2, 'xcv,kcv', '1437386543'),
(0, 6, 2, 'qewqewlk', '1437386662'),
(0, 6, 1, 'hahhaahhahhaa', '1437386842'),
(0, 7, 1, 'Bwahahahhaha', '1437386876'),
(0, 7, 1, 'hahahahahahahhah', '1437387027'),
(0, 7, 1, 'weherer and whwene', '1437387035'),
(0, 9, 1, 'test', '1437389776'),
(0, 9, 2, 'Yeah! This is a test!', '1437389808'),
(0, 10, 2, 'test?', '1437389870'),
(0, 10, 1, 'Yeah! A TEST!', '1437389885'),
(0, 10, 5, 'OK. LE ME TEST', '1437389918'),
(0, 12, 2, 'Test?', '1437390434'),
(0, 12, 1, 'YEAH! A Test!', '1437390560'),
(0, 12, 5, 'HHHhhmmm?', '1437390794'),
(0, 14, 1, 'hhgjh', '1528112669'),
(0, 14, 1, 'bgcghgc', '1528112672'),
(0, 14, 1, 'mbmbmnbmnb', '1528112678'),
(0, 17, 6, 'hi', '1528114111'),
(0, 17, 6, 'hai', '1528114118'),
(0, 17, 7, 'wao', '1528116961'),
(0, 18, 7, 'sjdcjhsfgvjhgdfhjv', '1528118759'),
(0, 18, 6, 'jhsdgfjsgfjhsdfj', '1528118776'),
(0, 19, 6, 'i am fine uh?', '1528125705'),
(0, 20, 6, 'ge?\r\n', '1528125791'),
(0, 22, 6, 'afsdf', '1528140690');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` varchar(500) NOT NULL,
  `date_created` varchar(500) NOT NULL,
  `ImageColumnName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `user_id`, `content`, `date_created`, `ImageColumnName`) VALUES
(21, 6, 'sfsrgrgrg\r\n', '1528138971', ''),
(22, 6, 'qwewqe', '1528140678', '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `firstname`, `lastname`) VALUES
(6, 'zubair', '123', 'zubair', 'rao'),
(7, 'talha', '12345', 'talha', 'atiq');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
