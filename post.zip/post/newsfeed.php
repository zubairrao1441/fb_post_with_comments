<?php include('header.php'); ?>
	<form method="post" > 
					<textarea name="post_content" rows="2" cols="64" style="text-align:center;" placeholder=".........Write about picture........" required></textarea>
					<br>
					 <input style="margin-left: 480px;" type='file' name='UploadImage'>
					<button style="margin-left: 413px; color: grey; " name="post">&nbsp;POST</button>
					<br>
					<hr>
					</form>
						<?php	
						extract($_POST);
if (isset($_POST['UploadImage'])) {
	# code...

$UploadedFileName=$_FILES['UploadImage']['name'];
if($UploadedFileName!='')
{
  $upload_directory = "MyUploadImages/"; //This is the folder which you created just now
  $TargetPath=time().$UploadedFileName;
  if(move_uploaded_file($_FILES['files']['tmp_name'], $upload_directory.$TargetPath)){    
    $QueryInsertFile=mysql_query("INSERT INTO post SET ImageColumnName='$TargetPath'"); 
    // Write Mysql Query Here to insert this $QueryInsertFile   .                   
 }							 }
}
							$query = mysql_query("SELECT *,UNIX_TIMESTAMP() - date_created AS TimeSpent from post LEFT JOIN user on user.user_id = post.user_id order by post_id DESC")or die(mysql_error());
							while($post_row=mysql_fetch_array($query)){
							$id = $post_row['post_id'];	
							$upid = $post_row['user_id'];	
							$posted_by = $post_row['firstname']." ".$post_row['lastname'];

						?>
					<a style="text-decoration:none; float:right;" href="deletepost.php<?php echo '?id='.$id; ?>"><button><font color="red">x</button></font></a>
					<h3>Posted by: <a href="#"> <?php echo $posted_by; ?></a>
					-
						<?php				
								$days = floor($post_row['TimeSpent'] / (60 * 60 * 24));
								$remainder = $post_row['TimeSpent'] % (60 * 60 * 24);
								$hours = floor($remainder / (60 * 60));
								$remainder = $remainder % (60 * 60);
								$minutes = floor($remainder / 60);
								$seconds = $remainder % 60;
								if($days > 0)
								echo date('F d, Y - H:i:sa', $post_row['date_created']);
								elseif($days == 0 && $hours == 0 && $minutes == 0)
								echo "A few seconds ago";		
								elseif($days == 0 && $hours == 0)
								echo $minutes.' minutes ago';
						?>
					<br>
					<br style="text-align: left;"><?php echo $post_row['content'];?></h3>
					<img style="width: 400px; height: 300px;"
					 src="<?php echo $post_row['ImageColumnName'];?>">
					<form method="post" style="color: grey;">
					<hr>
					Comment:<br>
					<input type="hidden" name="id" value="<?php echo $id; ?>">
					<textarea name="comment_content" rows="2" cols="44" style="text-align:center;" placeholder=".........Type your comment here........" required></textarea><br>
					<input type="submit" name="comment">
					</form>
						
					</br>
				
							<?php 
								$comment_query = mysql_query ("SELECT * ,UNIX_TIMESTAMP() - date_posted AS TimeSpent FROM comment LEFT JOIN user on user.user_id = comment.user_id where post_id = '$id'") or die (mysql_error());
								while ($comment_row=mysql_fetch_array($comment_query)){
								$comment_id = $comment_row['comment_id'];
								$comment_by = $comment_row['firstname']." ".  $comment_row['lastname'];
							?>
					<br><a href="#" style="color: white;"><?php echo $comment_by; ?></a> - <?php echo $comment_row['content']; ?>
					<br style="color: white;">
							<?php				
								$days = floor($comment_row['TimeSpent'] / (60 * 60 * 24));
								$remainder = $comment_row['TimeSpent'] % (60 * 60 * 24);
								$hours = floor($remainder / (60 * 60));
								$remainder = $remainder % (60 * 60);
								$minutes = floor($remainder / 60);
								$seconds = $remainder % 60;
								if($days > 0)
								echo date('F d, Y - H:i:sa', $comment_row['date_posted']);
								elseif($days == 0 && $hours == 0 && $minutes == 0)
								echo "A few seconds ago";		
								elseif($days == 0 && $hours == 0)
								echo $minutes.' minutes ago';
							?>
					<br>
							<?php
							}
							?>
					<hr
					&nbsp;
					<?php 
					if ($u_id = $id){
					?>
					
				
					
					<?php }else{ ?>
						
					<?php
					} } ?>
					
				
							<?php
								if (isset($_POST['post'])){
								$post_content  = $_POST['post_content'];
								
								mysql_query("insert into post (content,date_created,user_id) values ('$post_content','".strtotime(date("Y-m-d h:i:sa"))."','$user_id') ")or die(mysql_error());
								header('location:newsfeed.php');
								}
							?>

							<?php
							
								if (isset($_POST['comment'])){
								$comment_content = $_POST['comment_content'];
								$post_id=$_POST['id'];
								
								mysql_query("insert into comment (content,date_posted,user_id,post_id) values ('$comment_content','".strtotime(date("Y-m-d h:i:sa"))."','$user_id','$post_id')") or die (mysql_error());
								header('location:newsfeed.php');
								}
							?>
					</form>


</body>
</html>



			

			