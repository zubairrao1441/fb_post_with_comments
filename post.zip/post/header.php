
<!DOCTYPE html>
<html>

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style1.css">
	<script src="js1/jquery-3.2.1.min.js"></script>
	<script src="js1/bootstrap.js"></script>



	<title> Home Page </title> 
<?php include('dbconn.php'); ?>
	<?php include('session.php'); ?>
</head>





<body class="background" style="text-align: center;">
	<nav class="navbar navbar-inverse navbarCss">
		<div class="container-fluid">

			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span> 
				</button>
				<a class="navbar-brand planeroHeading" href="" > Planero</a>
			</div>

			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav">
					<li  ><a href="#">Home</a></li>
					<li class="active"> <a href="">Photographers</a></li>


			<li class="dropdown  "> 
              <a class="dropdown-toggle " data-toggle="dropdown" href="">Bookings
                <span class="caret"></span></a>
                <ul  style = "background: black !important; " class="dropdown-menu">
                  <li><a style = " color: white;" href=""> Pending Bookings</a> </li>
                  
                  <li><a style = " color: white;" href=""> Approved Bookings</a> </li>
                 
                  <li><a style = " color: white;" href=""> Compeleted Bookings</a> </li>

                  <li><a style = " color: white;" href=""> Dissapproved Bookings</a> </li>

                 
                             
                </ul>
              </li> 
				


					<li> <a href="#">Venue Tool</a> </li>
					<li> <a href="newsfeed.html">News Feed</a> </li>
				</ul>
				<ul class="nav navbar-nav navbar-right nav-right-button">
					<li  ><a href="changePassword.php"></a></li>
					<li><a href="#"><button><?php 
				echo $member_row['firstname']." ".$member_row['lastname'];
			?> </button></a></li>
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</div>
		</div>
	</nav>
